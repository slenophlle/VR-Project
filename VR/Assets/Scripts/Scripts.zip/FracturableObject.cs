using System.Collections;
using UnityEngine;

public class FracturableObject : MonoBehaviour
{
    private FracturePropManager fractureManager;
    private Rigidbody rb;

    [Header("Deprem Etkisi")]
    public bool shouldBreakAfterEarthquake = false; // Depremden sonra belirli s�rede k�r�lacak m�?
    public float breakDelay = 3f; // Deprem ba�lad�ktan sonra ka� saniye sonra k�r�lacak?

    [Header("Hareket Hassasiyeti")]
    public float movementThreshold = 0.05f; // �ok ufak hareketlerde bile k�r�lmay� tetikleme e�i�i
    public float velocityCheckTime = 0.1f; // Hareketi kontrol etmek i�in bekleme s�resi

    private bool earthquakeStarted = false;
    private bool isCheckingFall = false;

    void Start()
    {
        fractureManager = FindObjectOfType<FracturePropManager>();
        rb = GetComponent<Rigidbody>();

        if (rb == null && !shouldBreakAfterEarthquake)
        {
            Debug.LogWarning(gameObject.name + " nesnesinde Rigidbody yok! Sadece deprem sonras� k�r�labilir.");
        }
    }

    void Update()
    {
        if (!shouldBreakAfterEarthquake && rb != null) // Sadece Rigidbody olanlar d��me kontrol� yapacak
        {
            if (!isCheckingFall)
            {
                StartCoroutine(CheckMovement());
            }
        }
    }

    IEnumerator CheckMovement()
    {
        isCheckingFall = true;
        yield return new WaitForSeconds(velocityCheckTime);

        if (rb.velocity.magnitude < movementThreshold) // �ok k���k hareket alg�land���nda
        {
            Debug.Log("Hareket e�ik de�erin alt�na d��t�! K�r�l�yor: " + gameObject.name);
            fractureManager.TriggerFracture(gameObject);
        }

        isCheckingFall = false;
    }

    // Deprem s�ras�nda otomatik k�r�lma i�in �a�r�l�r
    public void StartBreakingCountdown()
    {
        if (!earthquakeStarted && shouldBreakAfterEarthquake)
        {
            earthquakeStarted = true;
            Debug.Log("Deprem s�ras�nda k�r�lma ba�lat�ld�: " + gameObject.name);
            StartCoroutine(DelayedFracture());
        }
    }

    IEnumerator DelayedFracture()
    {
        Debug.Log(gameObject.name + " i�in k�r�lma gecikmesi ba�lat�ld�, s�re: " + breakDelay + " saniye.");
        yield return new WaitForSeconds(breakDelay); // Belirtilen s�reyi bekle

        Debug.Log("Deprem sonras� k�r�lma tetiklendi: " + gameObject.name);
        fractureManager.TriggerFracture(gameObject); // Obje k�r�lmas�n� tetikle
    }
}
