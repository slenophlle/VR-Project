[System.Serializable]
public class Question
{
    public string questionText; // Soru metni
    public string[] answers;    // Cevaplar
    public int correctAnswerIndex; // Do�ru cevab�n indexi
}
