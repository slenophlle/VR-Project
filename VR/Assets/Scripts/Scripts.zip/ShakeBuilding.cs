using UnityEngine;

public class ShakeBuilding : MonoBehaviour
{
    public float intensity = 0.2f; // Deprem �iddeti
    public float frequency = 1f;   // Deprem titre�im s�kl���
    public float duration = 10f;   // Deprem s�resi

    private Vector3 originalPosition;
    private Quaternion originalRotation;
    private float timer = 0f;
    private bool isShaking = false;

    private float initialIntensity;
    private float initialFrequency;

    public Rigidbody buildingRb;

    void Start()
    {
        originalPosition = transform.position;
        originalRotation = transform.rotation;

        initialIntensity = intensity;
        initialFrequency = frequency;
    }

    void FixedUpdate()
    {
        if (isShaking)
        {
            if (timer < duration)
            {
                timer += Time.fixedDeltaTime;

                float timeOffset = Time.time * frequency;

                // Daha do�al hareket i�in 3 farkl� Perlin Noise de�eri hesaplayal�m
                float randomX = (Mathf.PerlinNoise(timeOffset, 0.5f) - 0.5f) * intensity;
                float randomZ = (Mathf.PerlinNoise(0.5f, timeOffset) - 0.5f) * intensity;
                float randomY = (Mathf.PerlinNoise(timeOffset * 0.5f, 0.2f) - 0.5f) * intensity * 0.1f;

                Vector3 shakeOffset = new Vector3(randomX, randomY, randomZ);
                buildingRb.MovePosition(originalPosition + shakeOffset);

                // Hafif d�nme hareketi ekleyelim
                float randomRotZ = (Mathf.PerlinNoise(timeOffset, 0.3f) - 0.5f) * intensity * 2;
                float randomRotX = (Mathf.PerlinNoise(0.3f, timeOffset) - 0.5f) * intensity * 2;

                Quaternion shakeRotation = Quaternion.Euler(randomRotX, 0, randomRotZ);
                buildingRb.MoveRotation(originalRotation * shakeRotation);

                // Deprem �iddetini zamanla azalt
                float progress = timer / duration;
                intensity = Mathf.Lerp(initialIntensity, 0, progress);
                frequency = Mathf.Lerp(initialFrequency, 0, progress);
            }
            else
            {
                StopShake();
            }
        }
    }

    public void StartShake(float quakeIntensity, float quakeFrequency, float quakeDuration)
    {
        intensity = quakeIntensity;
        frequency = quakeFrequency;
        duration = quakeDuration;

        initialIntensity = quakeIntensity;
        initialFrequency = quakeFrequency;
        timer = 0f;
        isShaking = true;
    }

    public void StopShake()
    {
        isShaking = false;
        buildingRb.MovePosition(originalPosition);
        buildingRb.MoveRotation(originalRotation);

        intensity = initialIntensity;
        frequency = initialFrequency;
    }
}
